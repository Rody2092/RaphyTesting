exports.run = async (client, message, args) => {
  message.inlineReply('Itachi Uchiha, é o meu senpai! :heart:')
}